function doubleAfteraWhile(x) {
    return new Promise(resolve => { 
      setTimeout(() => { // The setTimeout here is used to mimic the effect of the real-worold delay that comes from sending requests to HTTP calls/ databases etc
        resolve(x * 2);
      }, 500);
    });
  }
  
  async function addAsync(x) {
    var a = await doubleAfteraWhile(10); // the await keyword makes the program wait for this function to return before using any "awaited" data
    var b = await doubleAfteraWhile(20);
    var c = await doubleAfteraWhile(30);
    return x + a + b + c;
  }




  
  function main(){
  // Do something async
    addAsync(10).then((sum) => {
    console.log(sum);
    console.log('I took a little while so I finished later. Look no bugs!');
  });

  // This is something that doens't need the async
  console.log("I was read later, but the async didn't finish yet");

}

main();