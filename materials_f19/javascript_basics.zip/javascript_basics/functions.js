// Functions are a vital tool in any programming language. In particular functions control the scope of variables
// JavaScript functions are similar to C++ functions in their declaration, except there is only one type of function

// Declaring Functions

function myFirstFunction(){}; // A function requires the function declaration word, its name, parenthesis for any arguments, and curly brackets for the code
myFirstFunction(); 

function mySecondFunction(){ // The body of the functions lies between the curely brackets
    console.log('Hello World');
};
mySecondFunction();

function myThirdFunction(name){
    console.log('Hello',name);
};
myThirdFunction('Ada');

// Scope
// Understanding variable scope - which is where in the running code that variable can be accessed - is imperative
var scope = 'level0';


function messUpMyScope(input){
    var scope = input;
    //scope = input; // BEWARE OF GLOBAL DEFINITIONS - DO NOT USE
    console.log('scope level:',scope);
}

messUpMyScope('level1');
console.log('scope level:',scope);