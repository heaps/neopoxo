// Technically everything in JavaScript is an object, incl. variables, arrays, and functions
// Objects are vitally important and are used to send and recieve data accross the web. 
// Objects are constructed from key-value pairs, the keys are strings and the values can be arrays, objects, or variables

var emptyobj = {}; // an empty object
var obj = {'keyname1':1}; // creating an object with one key-value pair
// adding to objects can be done in two ways
obj.keyname2 = 5; // most common way of adding a single key-value
obj.keyname3 = [1,2,3,4,5];

obj['keyname4'] = 6; // less commonly used way to add items, but can be useful in certain cases
obj['keyname5'] = [2,4,6,8,10];

console.log(obj);

// retrieiving a value from the object is similar to adding
var number5 = obj.keyname2; 
console.log(number5);
// traversing through an object is an import skill as large objects can have several layers
var number10 = obj.keyname5[4]; // obj.keyname4 is an array, so once we are at the array we need to use array notation
console.log(number10);