
// Being a weakly typed language, JavaScript lets you define variables without specifying the type
// Primitives
// Numbers
var number = 10;
number = 10 + 5.5;
console.log(number);
// Strings
var string = 'hello';
string = string.toLocaleUpperCase();
console.log(string);
// Charcters
var character = '#';
character=character+'5';
console.log(character);
// Booleans
var boolean = true;
boolean = 5<3;
console.log(boolean);