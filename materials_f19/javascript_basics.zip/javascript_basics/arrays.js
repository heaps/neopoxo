// Javascript arrays are similar to C++ and python arrays
// They can hold any mixture of different variables, even other arrays and objects
var array = ['hi','how','are','you',2,3,4,5,[6,7,8],{'name':'default'}];
// JavaScript Arrays are zero-based
console.log(array[0]);
for(var i=0; i<array.length; i++){
    console.log(array[i]);
}
// Arrays have a number of inbuilt functionality that will be commonplace to use
// push
var newArray = []; // creates an empty array
console.log(newArray);
newArray.push(4);
newArray.push(5);
newArray.push(6);
newArray.push(7,8,'nine'); // we can push multiple items at once
console.log(newArray);
// pop
newArray.pop();
console.log(newArray);
// slice
newArray2 = newArray.slice(0,2);
console.log('newArray',newArray);
console.log('newArray2',newArray2);