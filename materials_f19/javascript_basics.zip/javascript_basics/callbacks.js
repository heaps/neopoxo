
// Callback functions are a cruicial part of asynchronous programming. 
// These functions essentully wait for some other function to complete before executing

// A simple example
function myfunc(variable){ // regular function, no callback
    console.log(variable);
}
myfunc('hello');


function myfunc_w_callback(variable,callback_func){
    callback_func(variable); // this will apply the func that is passed in onto the variable
}
function upperandlog(variable){ // we can define the function seperately
    var upperVariable = variable.toUpperCase();
    console.log(upperVariable);
}
myfunc_w_callback('hello',upperandlog);


myfunc_w_callback('hello',function(variable){ // we can also define the callback when we call the function
    var upperVariable = variable.toUpperCase();
    console.log(upperVariable);
});

// Arrays contain special formats for these callbacks
var array = [-5,-4,-3,-2,-1,0,1,2,3,4,5,6];
// forEach
var newarray = [];
array.forEach(function(item){ // essentially forEach is just a shorter for loop
    newarray.push(item *=-1);
});
console.log(array);
console.log(newarray);

// map
var newarray2 = array.map(function(item){ // map returns a new array with the values manipulated based on the callback
    return item*=-2;
});
console.log(array);
console.log(newarray2);

// filter
var onlyPosarray = array.filter(function(item){ // returns any item that passes the boolean test to a new array
    var isPositive = false;
    if(item>0){
        isPositive=true;
    }
    return isPositive;
});
console.log(array);
console.log(onlyPosarray);

// reduce 
var arraySum = array.reduce(function(currentValue,thisValue){ // takes each element of the array and combines them based on the callback, returns the final value
    return currentValue+thisValue;
},0);
console.log(array);
console.log(arraySum);